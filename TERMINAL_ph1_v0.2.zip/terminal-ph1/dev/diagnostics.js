// dev/diagnostics.js — the Phase 1 QA gate (§8). Importable (browser) + runnable (node).
import { ZONE_KEYS } from "../src/config/zones.js";
import { ASSETS, assetById } from "../src/config/assets.js";
import { RealClock } from "../src/engine/realClock.js";
import { createSimClock } from "../src/engine/simClock.js";
import { MarketHours } from "../src/engine/marketHours.js";
import { OfflineResolver } from "../src/engine/offlineResolver.js";
import { initialState, netWorth, rankFor } from "../src/state/state.js";
import { SaveSystem } from "../src/state/save.js";
import { validateAsset, validateSaveState, validateHolding } from "../src/state/schema.js";

const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);

export async function runAll() {
  const results = [];
  const check = (name, cond, detail = "") => results.push({ name, ok: !!cond, detail });

  // 1) SCHEMAS — accept good, reject bad
  check("schema: all 9 assets valid", ASSETS.every(a => validateAsset(a).ok));
  check("schema: rejects bad cls", !validateAsset({ ...ASSETS[0], cls: "STONKS" }).ok);
  check("schema: rejects unknown key", !validateAsset({ ...ASSETS[0], wat: 1 }).ok);
  check("schema: rejects dividend on non-bluechip", !validateAsset({ ...ASSETS[3], dividendYield: 0.05 }).ok);
  check("schema: rejects negative holding qty", !validateHolding({ assetId: "ORB", qty: -1, avgCost: 5 }).ok);
  check("schema: fresh initialState validates", validateSaveState(initialState()).ok);
  check("schema: rejects unknown save key", !validateSaveState({ ...initialState(), hacker: true }).ok);

  // 2) REALCLOCK
  const uh = RealClock.utcHours();
  check("realClock: utcHours in [0,24)", uh >= 0 && uh < 24);
  const lt = RealClock.localTime("LONDON");
  check("realClock: localTime label", lt.label === "London" && lt.h >= 0 && lt.h < 24);

  // 3) MARKETHOURS — known hours + midnight wrap
  check("hours: NEWYORK open at 14:00", MarketHours.isOpen("NEWYORK", 14));
  check("hours: NEWYORK closed at 02:00", !MarketHours.isOpen("NEWYORK", 2));
  check("hours: LONDON open at 10:00", MarketHours.isOpen("LONDON", 10));
  check("hours: SYDNEY wrap open at 23:00", MarketHours.isOpen("SYDNEY", 23));
  check("hours: SYDNEY wrap open at 00:00", MarketHours.isOpen("SYDNEY", 0));
  check("hours: SYDNEY closed at 13:00", !MarketHours.isOpen("SYDNEY", 13));
  // full 24h sweep returns booleans for every zone
  let sweepOk = true;
  for (let h = 0; h < 24; h += 0.25) for (const z of ZONE_KEYS) if (typeof MarketHours.isOpen(z, h) !== "boolean") sweepOk = false;
  check("hours: 24h sweep all boolean", sweepOk);

  // 4) ASSETTRADABLE — class rules at h=23 (TOKYO open; LON/NY closed)
  check("tradable: crypto always (h=23)", MarketHours.assetTradable(assetById("ORB"), 23));
  check("tradable: rare always (h=23)", MarketHours.assetTradable(assetById("NEO"), 23));
  check("tradable: gold closed when LON+NY closed (h=23)", !MarketHours.assetTradable(assetById("AUX"), 23));
  check("tradable: KMG(Tokyo) open at h=23", MarketHours.assetTradable(assetById("KMG"), 23));
  check("tradable: AVT(NY) closed at h=23", !MarketHours.assetTradable(assetById("AVT"), 23));
  check("tradable: gold open at h=14 (NY open)", MarketHours.assetTradable(assetById("AUX"), 14));

  // 5) SIMCLOCK — rate + mode + cadence
  const sc = createSimClock();
  check("sim: idle rate 1", sc.rate === 1);
  sc.setMode("active");
  check("sim: active rate 60", sc.rate === 60);
  check("sim: simMsFor 1000ms@60x = 60000", sc.simMsFor(1000) === 60000);
  sc.setMode("fastforward");
  check("sim: fastforward rate 300", sc.rate === 300);
  let threw = false; try { sc.setMode("warp"); } catch { threw = true; }
  check("sim: bad mode throws", threw);
  // one real tick
  sc.setMode("active");
  const tick = await new Promise(res => { sc.start(t => { sc.stop(); res(t); }); });
  check("sim: onTick shape {realDeltaMs,simMs}", typeof tick.realDeltaMs === "number" && typeof tick.simMs === "number");
  sc.stop();

  // 6) STATE selectors
  const st = initialState();
  st.holdings = [{ assetId: "ORB", qty: 2, avgCost: 60000 }];
  st.cash = 10000;
  const nw = netWorth(st, id => ({ ORB: 61240 }[id] || 0));
  check("state: netWorth = cash + qty*price", nw === 10000 + 2 * 61240);
  check("state: rankFor(60000) === 4", rankFor(60000) === 4);
  check("state: rankFor(10000) === 1", rankFor(10000) === 1);

  // 7) SAVE round-trip
  SaveSystem.clear();
  const before = initialState();
  before.holdings = [{ assetId: "AUX", qty: 3, avgCost: 2010 }];
  before.cash = 4321.55;
  SaveSystem.save(before);
  const after = SaveSystem.load();
  check("save: round-trip deep-equal", eq(before, after));

  // 8) MIGRATION v0.1 -> v0.2, lossless
  const legacy = {
    version: "0.1",
    homeZone: "TOKYO",
    lastSeenTs: 1719000000000,
    cash: 7777,
    holdings: { ORB: 2, AUX: 1 }, // old map shape
    cost: { ORB: 60000, AUX: 2000 },
  };
  const { state: migrated, migrationsApplied } = SaveSystem.deserialize(JSON.stringify(legacy));
  check("migrate: schemaVersion now 0.2", migrated.schemaVersion === "0.2");
  check("migrate: holdings became array", Array.isArray(migrated.holdings) && migrated.holdings.length === 2);
  check("migrate: cash preserved", migrated.cash === 7777);
  check("migrate: avgCost carried from old cost map", migrated.holdings.find(h => h.assetId === "ORB").avgCost === 60000);
  check("migrate: migrationsApplied recorded", migrationsApplied.length > 0);
  check("migrate: result validates", validateSaveState(migrated).ok);

  // 9) OFFLINE RESOLVER — elapsed + transitions + dividend hook
  let hookArgs = null;
  const saved = { ...initialState(), lastSeenTs: Date.now() - 11 * 3600 * 1000, holdings: [{ assetId: "HBC", qty: 5, avgCost: 88 }] };
  const res = OfflineResolver.resolveOnLoad(saved, Date.now(), a => { hookArgs = a; });
  check("offline: elapsedMs ~ 11h", Math.abs(res.elapsedMs - 11 * 3600 * 1000) < 60000);
  check("offline: zone transitions detected over 11h", res.zoneTransitions.length > 0);
  check("offline: transition shape", res.zoneTransitions.every(t => t.zone && (t.kind === "opened" || t.kind === "closed") && typeof t.atMs === "number"));
  check("offline: dividend hook called with holdings", hookArgs && Array.isArray(hookArgs.holdings) && hookArgs.holdings.length === 1);

  const pass = results.filter(r => r.ok).length;
  const fail = results.length - pass;
  return { pass, fail, total: results.length, results };
}

// node entrypoint
const isNode = typeof process !== "undefined" && process.versions && process.versions.node;
if (isNode) {
  runAll().then(r => {
    for (const x of r.results) console.log(`${x.ok ? "PASS" : "FAIL"}  ${x.name}${x.detail ? "  — " + x.detail : ""}`);
    console.log(`\n${r.fail === 0 ? "ALL PASS" : r.fail + " FAILED"}  (${r.pass}/${r.total})`);
    process.exit(r.fail === 0 ? 0 : 1);
  }).catch(e => { console.error(e); process.exit(1); });
}
